using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OnlineFoodOrder.Views.Shared
{
    public class _LoginPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
